<?php

/** @var \Laravel\Lumen\Routing\Router $router */

$router->group(['prefix' => 'collections'], function () use ($router) {
    $router->post('getCollections', 'App\Modules\Collection\Controllers\CollectionController@getCollections');
     $router->post('claim', 'App\Modules\Collection\Controllers\CollectionController@claim');
});
