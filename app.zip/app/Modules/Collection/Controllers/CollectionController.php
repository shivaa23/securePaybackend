<?php

namespace App\Modules\Collection\Controllers;

use Laravel\Lumen\Routing\Controller as BaseController;
use App\Traits\ApiResponser;
use Illuminate\Http\Request;
use App\Modules\Collection\Models\Collection;
use App\Modules\Account\Models\AccountStatement;
use App\Modules\Bank\Models\BankStatement;
use App\Modules\User\Models\User;
use App\Modules\Account\Models\AccountValidation;
use Auth;
use DB;
use Validator;
use App\Helper\ResponseHelper;
use Illuminate\Support\Facades\Crypt;
use App\Modules\Auth\Models\Otp;
use App\Modules\Commission\Models\CommRule;
use App\Modules\Commission\Models\AcommRule;
use App\Modules\WalletLedger\Services\WalletService2;
use App\Modules\Service\Models\Service;
use Carbon\Carbon;

class CollectionController extends BaseController
{
    use ApiResponser;

    public function __construct(){
        $this->middleware('auth', ['except' => ['createAccount','updateAccount','encryptPayload']]);
        $this->middleware('check.active', ['except' => '']);
        $this->middleware('check.service.time',['except' => '']);
    }  
    public function getCollections(Request $request)
    {
        $user = Auth::user();
    
        $query = Collection::query();
        if (!in_array($user->role, ['sadm', 'adm'])) {
            $query->where('user_id', $user->id);
        }
    
        if ($request->filled('rrn')) {
            $query->where('rrn', $request->rrn);
        }
          if ($request->filled('amount')) {
            $query->where('amount', $request->amount);
        }
          if ($request->filled('user_id')) {
            $query->where('user_id', $request->user_id);
        }
           if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('payerName')) {
            $query->where('payerName', 'LIKE', '%' . $request->payerName . '%');
        }
          if ($request->filled('payerAddress')) {
            $query->where('payerAddress', 'LIKE', '%' . $request->payerAddress . '%');
        }
           if ($request->filled('from_date') && $request->filled('to_date')) {
             $query->whereDate('created_at', '>=', $request->from_date)
                  ->whereDate('created_at', '<=', $request->to_date);
             }
                            $today = Carbon::now()->format('Y-m-d');
                $totalsQuery = clone $query; // clone base query (with role + filters)
                
                if ($request->filled('from_date') && $request->filled('to_date')) {
                    // Totals for selected date range
                    $totalsQuery->whereDate('created_at', '>=', $request->from_date)
                                ->whereDate('created_at', '<=', $request->to_date);
                } else {
                    // Totals for today only
                    $totalsQuery->whereDate('created_at', $today);
                }
                $unclaimedAmt = (clone $totalsQuery)->where('status', 'Unclaimed')->sum('amount');
                $claimedAmt  = (clone $totalsQuery)->where('status', 'Claimed')->sum('amount');
                $totalAmount = (clone $totalsQuery)->sum('amount');
    
        // $collections = $query->get();
            $collections = $query->latest()->paginate($request->input('paginate', 15));
    
        // return ResponseHelper::success(
        //     'Collections fetched successfully',
        //     $collections,
        //     200
        // );
              return ResponseHelper::success('Transactions fetched', [
                  'total_amount' => $totalAmount,
                'total_claimed_amount' => $claimedAmt,
                'total_unclaimed_amount'  => $unclaimedAmt,
                'data' => $collections
            ], 200);
                //  return ResponseHelper::success('Transactions fetched', $collections, 200);
    }
    public function claim(Request $request)
    {
        $user = Auth::user();
    
        // Validate only ID
        $validator = Validator::make($request->all(), [
            'id' => 'required|integer|exists:collections,id',
             'remark' => 'sometimes|string',
        ]);
    
        if ($validator->fails()) {
            return ResponseHelper::error($validator->errors(), 'Validation error', 422);
        }
    
        // Fetch collection
        $collections = Collection::find($request->id);
        if (!$collections) {
            return ResponseHelper::error("Collection not found", [], 404);
        }
    
        // Fix incorrect status condition
        if ($collections->status !== "Unclaimed") {
            return ResponseHelper::error("Collection status is already {$collections->status}", [], 403);
        }
    
        // Fetch service
        $service = Service::find(92);
        if (!$service) {
            return ResponseHelper::error("Service not found", [], 404);
        }
          if ($service->is_active==0) {
            return ResponseHelper::error("Service  is not active", [], 403);
        }
        // Commission check
        $comm = CommRule::calculateCommission($user, $service->name, $collections->amount);
        if (!$comm) {
            return ResponseHelper::error('Commission Slab Not Configured', [], 403);
        }
    
        $a_comm = AcommRule::calculateAdminCommission(
            $service->name,
            $collections->amount,
            $service->route
        );
        if (!$a_comm) {
            return ResponseHelper::error('Admin Commission Slab Not Configured', [], 403);
        }
    
        // Final commission calculation
        $comm = CommRule::finalCommission($comm, $collections->amount, $service);
        $a_comm = AcommRule::finalCommission($a_comm, $collections->amount);
    
        DB::beginTransaction();
        try {
    
            WalletService2::claim($user, $collections, $service);
    
            $collections->status = "Claimed";
              $collections->remark = $request->remark;
            $collections->save();
    
            DB::commit();
    
            return ResponseHelper::success("Claim processed successfully", [], 200);
    
        } catch (\Exception $e) {
    
            DB::rollBack();
            return ResponseHelper::error('Claim Failed', $e->getMessage(), 500);
        }
    }




    public function createAccount(Request $request){ 
        if (!in_array(Auth::user()->role, ['sadm', 'adm'])) {
            return ResponseHelper::error('Unauthorised Action', [], 403);
        }
       	$validator = AccountValidation::createAccount($request->all());
        if ($validator->fails()) {
            return ResponseHelper::error($validator->errors(),'Validation Failed',  422);
        }
        $user=User::find($request->user_id);
        $account=new Account();
        $accountData=  $account->where("user_id",$request->user_id)->first();
        if ($accountData) {
            return ResponseHelper::error('Account already exists', [], 403);
        }

        // $account->account=$request->account;
        $account->name          = $request->name ??$user->name;
        $account->user_id       = $request->user_id;
        $account->establishment = $request->establishment ??$user->establishment;
        $account->mobile        = $request->mobile ??$user->mobile;
        $account->asm    = $user?$user->parent:null;
        $account->credit_limit  = $request->credit_limit ;
        $account->balance       = $request->balance ??0;
  
        
        if($account->save()){
            return ResponseHelper::success('Account Created Successfully', $account, 200);
        }else{
            return ResponseHelper::error('Something Went Wrong', '', 403);

        }
    }
    
    public function updateAccount(Request $request){
       	$validator = AccountValidation::updateAccount($request->all());
        if ($validator->fails()) {
            return ResponseHelper::error( $validator->errors(),'Validation Error', 422);
        }
        if (!in_array(Auth::user()->role, ['sadm', 'adm',])) {
            return ResponseHelper::error('Unauthorised Action', [], 403);
        }
        $account=Account::find($request->id);
        if (!$account) {
            return ResponseHelper::error('Account not found', '', 403);
        }
        if($account){
            $account->name          = $request->name ?? $account->name;
            $account->user_id       = $request->user_id ?? $account->user_id;
            $account->establishment = $request->establishment ?? $account->establishment;
            $account->mobile        = $request->mobile ?? $account->mobile;
            //$account->type        = $request->type ?? $account->type;
            $account->asm           = $request->asm ?? $account->asm;
            $account->credit_limit  = $request->credit_limit ?? $account->credit_limit;
            $account->balance       = $request->balance ?? $account->balance;
            $account->status        = $request->status??$account->status;
            if($account->save()){
                return ResponseHelper::success('Account updated Successfully',$account, 200);
            }
        }else{
            return ResponseHelper::error('Account not found', '', 403);
        }
    }
    
    public function getAccountSchema(){
        $schema = AccountValidation::getAccountSchema();
        return  ResponseHelper::success('Schema fetchSuccessfully',$schema, 200);;
    }
    public function deleteAccount(Request $request){
        $validator = AccountValidation::deleteAccount($request->all());
        if ($validator->fails()) {
            return ResponseHelper::error($validator->errors(),'Validation Failed',  422);
        }
    
        $account = Account::find($request->id);
        if ($account->delete()) {
            return ResponseHelper::success( 'Account deleted successfully', [], 200);
        }
        return ResponseHelper::error('Account could not be deleted', [], 403);
    }
     public function getAccounOthertSchema(){
        $schema = AccountValidation::getAccountOthersSchema();
        return  ResponseHelper::success('Schema fetchSuccessfully',$schema, 200);;
    }
    public function deleteLastTxn(Request $request){
        $rules = ['account_id' => 'required'];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return ResponseHelper::error($validator->errors(),'Validation Error', 403);
        }
        if (Auth::user()->role != 'sadm') {
            return ResponseHelper::error('Unauthorised Access', '', 403);
        }
        $txna = AccountStatement::where('account_id', $request->account_id)
                    ->latest()
                    ->first();
        if (!$txna) {
            return ResponseHelper::error('No Transaction Found To Delete', '', 403);
        }
        try {
            DB::beginTransaction();
            $credit = $txna->credit ?? 0;
            $debit  = $txna->debit ?? 0;
            $user = Account::find($txna->account_id);
            if (!$user) {
                DB::rollBack();
                return ResponseHelper::error('Account not found', '', 404);
            }
            // Adjust balance
            $user->increment('balance', $credit);
            $user->decrement('balance', $debit);
            // Update bank transaction if applicable
            $bnkTxn = BankStatement::find($txna->bank_txnid);
            if ($bnkTxn && $bnkTxn->status == 1) {
                $bnkTxn->status = 0;
                $bnkTxn->save();
            }
            // Delete ledger entry
            $txna->delete();
            if ($txna) {
                DB::commit();
                return ResponseHelper::success('Transaction deleted successfully', '', 200);
            } else {
                DB::rollBack();
                return ResponseHelper::error('Request cannot be processed this time', '', 403);
            }
        } catch (\Exception $e) {
            DB::rollBack();
            return ResponseHelper::error('Something went wrong: ' . $e->getMessage(), '', 500);
        }
    }
}
