<?php

namespace App\Modules\Dmt\Controllers;

use Laravel\Lumen\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use App\Modules\Dmt\Models\DmtTxn;
use App\Modules\Dmt\Models\FinBank;
use App\Modules\Dmt\Models\Dmt2Validation;
use Auth;
use App\Modules\Integration\Models\Psprint;
use App\Helper\ResponseHelper;
use Carbon\Carbon;
use App\Modules\Dmt\Services\Dmt2Service; 
use App\Modules\Commission\Models\CommRule;
use Illuminate\Support\Facades\DB;
use App\Modules\Service\Models\Service;
use App\Modules\Dmt\Models\DmtBeneficiarie;
 use App\Modules\WalletLedger\Services\WalletService;
 use App\Modules\AuditLog\Services\AuditService;
 use App\Modules\Dmt\Services\DMT2ResponseHandler;
 use App\Modules\Auth\Models\Otp;
class PaySprintController extends BaseController
{
      

    public function __construct()
    {
        $this->middleware('auth', ['except' => ['']]);
        $this->middleware('check.active', ['except' => '']);

    }
    
    public function getBanksDmt2(Request $request){
        $banks=FinBank::all();
        
          return ResponseHelper::success('Banks fetched', $banks, 200);
         
	}
	 
    public function getDmtTxns(){
        $user = Auth::user();
    
        if (in_array($user->role, ["sadm", "adm"])) {
            $dmttxns = DmtTxn::all();
            return ResponseHelper::success('Dmt Txns fetched', $dmttxns, 200);
        }
    
        $dmttxns = DmtTxn::where("user_id", $user->id)->get();
        return ResponseHelper::success('Dmt Txns fetched', $dmttxns, 200);
    }
	public function remitterStatusDmt2(Request $request)
    {
    $validator = Dmt2Validation::remitterStatus($request->all());
    if ($validator->fails()) {
        return ResponseHelper::error('Validation Failed', $validator->errors(), 422);
    }

    $data = $request->all();
    $data['ip'] = $request->ip();
    $data['order_id'] = Carbon::now()->timestamp . rand(100, 999);
    $data['url'] = 'https://api.paysprint.in/api/v1/service/dmt/kyc/remitter/queryremitter';
    $data['payload'] = json_encode([
        "mobile"     => $data['mobile_number'],
        "name"       => "KAMAL",
        "lat"        => $data['latitude'],
        "long"       => $data['longitude'],
        "accessmode" => "WEB"
    ]);
    $data['method'] = 'POST';

    $response = Psprint::service($data);
   
    if (!isset($response)) {
        return ResponseHelper::error('No response from API', [], 500);
    }

    $statusCode = $response['response_code'] ?? null;
    $beneficiaries = $response['data']['beneficiaries'] ?? [];
    if ($statusCode === 1) {
        // foreach ($beneficiaries as $bn) {
        //     dispatch(new \App\Jobs\ProcessBeneficiaryDmt2($request->mobile_number, $bn));
            
        // }
        $beneData = DmtBeneficiarie::where('sender', $request->mobile_number)
            ->where('pipe', 'DMT2')->orderBy('created_at', 'desc')
            ->get();

        $response['data']['beneficiaries'] = $beneData;
        return ResponseHelper::success('Remitter Found', $response['data'], 200);
    }

    switch ($statusCode) {
        case '0':
        case '2':
            return ResponseHelper::success($response['status'], $response['data'], 200);
        case 'ERR':
        default:
            return ResponseHelper::error($response['status'] ?? 'Unknown Error', $response['data'] ?? [], 403);
    }
}
    public function registerBeneficiaryDmt2(Request $request)
    {
        try {
            $validator = Dmt2Validation::registerBeneficiary($request->all());
            if ($validator->fails()) {
                return ResponseHelper::error('Validation Failed', $validator->errors(), 422);
            }
            //   $mpin=OTP::verifyMpin($request->mpin);
            // if(!$mpin){
            //      return ResponseHelper::error("invalid mpin", [], 403);
            // }
    
            $data = $request->all();
            $data['ip']       = $request->ip();
            $data['order_id'] = Carbon::now()->timestamp . rand(100, 999);
            $data['url']      = 'https://api.paysprint.in/api/v1/service/dmt/kyc/beneficiary/registerbeneficiary';
            $data['payload']  = json_encode([
                "mobile"    => $request->rem_mobile,
                "benename"  => $request->name,
                "bankid"    => $request->bank_id,
                "accno"     => $request->account_number,
                "ifsccode"  => $request->ifsc,
                "verified"  => $request->is_verified,
                "gst_state" => "07",
                "dob"       => "1990-03-02",
                "address"   => "New delhi",
                "pincode"   => "110085",
            ]);
            $data['method']   = 'POST';
            $res = Psprint::service($data);
            if (isset($res['response_code']) && $res['response_code'] == 1) {
                $beneficiary = DmtBeneficiarie::where('sender', $request->rem_mobile)
                    ->where('account_number', $request->account_number)
                    ->where('ifsc_code', $request->ifsc)
                    ->where('pipe', 'DMT2')
                    ->first();
    
                if (!$beneficiary) {
                    $newBeneficiary = new DmtBeneficiarie();
                    $newBeneficiary->sender            = $request->rem_mobile;
                    $newBeneficiary->mobile_number     = $request->rem_mobile;
                    $newBeneficiary->beneficiary_name  = str_replace([".", "/"], "", $res['data']['name']);
                    $newBeneficiary->bene_id           = $res['data']['bene_id'];
                    $newBeneficiary->account_number    = $res['data']['accno'];
                    $newBeneficiary->ifsc_code         = $res['data']['ifsc'];
                    $newBeneficiary->bank_name         = $res['data']['bankname'];
                    $newBeneficiary->pipe              = 'DMT2';
                    $newBeneficiary->is_verified       = $res['data']['verified'];
                    $newBeneficiary->save();
                } else {
                    $beneficiary->is_deleted = 0;
                    $beneficiary->save();
                }
    
                return ResponseHelper::success('Beneficiary registered successfully', $res, 200);
            }
    
           
            return ResponseHelper::error(
                $res['message'] ?? 'Beneficiary registration failed',
                $res,
                403
            );
    
        } catch (\Exception $e) {
            return ResponseHelper::error(
                $e->getMessage(),
                [
                    'line' => $e->getLine(),
                    'file' => $e->getFile(),
                ],
                500
            );
        }
    }
     public function removeBeneficiaryDmt2(Request $request)
    {
        // Validate
        $validator = Dmt2Validation::removeBeneficiary($request->all());
        if ($validator->fails()) {
            return ResponseHelper::error('Validation Failed', $validator->errors(), 422);
        }
          $mpin=OTP::verifyMpin($request->mpin);
        if(!$mpin){
             return ResponseHelper::error("invalid mpin", [], 403);
        }
    
        // Input values
        $remitterMobile = $request->rem_mobile;
        $beneficiaryId  = $request->bene_id ?? $request->ben_id;
    
        /*
       
        $data = $request->all();
        $data['ip']       = $request->ip();
        $data['order_id'] = Carbon::now()->timestamp . rand(100, 999);
        $data['url']      = 'https://api.paysprint.in/api/v1/service/dmt/kyc/beneficiary/registerbeneficiary/deletebene';
        $data['payload']  = json_encode([
            'mobile'  => $remitterMobile,
            'bene_id' => $beneficiaryId,
        ]);
        $data['method']   = 'POST';
    
        $res = Psprint::service($data);
    
        if (isset($res['statuscode']) && $res['statuscode'] == 1) {
        */
            
            $beneficiary = DmtBeneficiarie::where('sender', $remitterMobile)
                ->where('bene_id', $beneficiaryId)
                ->first();
    
            if (!$beneficiary) {
                return ResponseHelper::error('Beneficiary not found in system', [], 404);
            }
    
            $beneficiary->delete();
            return ResponseHelper::success('Beneficiary deleted successfully', $beneficiary, 200);
        /*
        }
    
        // Failure from API
        return ResponseHelper::error(
            $res['status'] ?? 'Beneficiary deletion failed',
            $res,
            403
        );
        */
    }
    public function getBeneficiarySchemaDmt2(Request $request){
          $schema = Dmt2Validation::getBeneficiarySchema($request);
           return ResponseHelper::success('schema fetched', $schema, 200);
     }
    public function dmt2Txn(Request $request)
    {
           $user = Auth::user();
            $validator = Dmt2Validation::dmt2Txn($request->all());
            if ($validator->fails()) {
                return ResponseHelper::error('Validation error', $validator->errors(),422);
            }
              $mpin=OTP::verifyMpin($request->mpin);
            if(!$mpin){
                 return ResponseHelper::error("invalid mpin", [], 403);
            }
             if (!in_array($user->role, ["api", "dd", "ret"])) {
                return ResponseHelper::error('Action not Authorised', '', 403);
            }
            if ($user->w1 < $request->amount * 100) {
                return ResponseHelper::error('Insufficient W1 Balance', '', 403);
            }
            $service = Service::find($request->operator);
            $comm = CommRule::calculateCommission($user, $service->name, $request->amount);
            if (in_array($user->role, ["api", "dd", "ret"])) {
                $comm = CommRule::finalCommission($comm, $request->amount,$service);
            }
            DB::beginTransaction();
            try {  
                $dmtTxn = Dmt2Service::create($user, $service, $request, $comm);
                WalletService::debit($user, $request->amount, $dmtTxn, $service);
                $auditLog = AuditService::logRequest($user, $request, $service);
            //   return $dmtTxn;
                DB::commit();
            } catch (\Exception $e) {
                DB::rollBack();
                return ResponseHelper::error('Recharge Init Failed', $e->getMessage(), 500);
            }
            $data = $request->all();
            $data['DUMMY']="DUMMY";
        	$data['order_id'] = $dmtTxn->txn_id;
					$data['url'] = 'https://api.paysprint.in/api/v1/service/dmt/kyc/transact/transact';
					$data['payload'] = '{"mobile":"'.$data['number'].'",
										"referenceid":"'.$dmtTxn->txn_id.'",  
										"pincode":110085,     
										"address":"New Delhi",     
										"dob":"01-07-1981",     
										"gst_state":"07",     
										"bene_id":"'.$data['ben_id'].'",     
										"txntype":"'.$data['type'].'",   
										"stateresp":"'.$data['stateresp'].'",   
										"otp":"'.$data['otp'].'",   
										"amount":"'.$data['amount'].'"
									}';
					$data['method'] = 'POST';
           
            $data['outlet_id']  = $user->instId;
            $response = Psprint::service($data);
    
         
          
            DB::beginTransaction();
            try {
                $result = DMT2ResponseHandler::handle($dmtTxn, $response, $user, $service, $comm);
                AuditService::updateResponse($auditLog, $response);
                DB::commit();
                return $result;
            } catch (\Exception $e) {
                DB::rollBack();
                return ResponseHelper::error('Recharge Update Failed', $e->getMessage(), 500);
            }
            
        }
    public function transactionOtpDmt2(Request $request)
    {
            $validator = Dmt2Validation::transactionOtpDmt2($request->all());
            if ($validator->fails()) {
                return ResponseHelper::error('Validation Failed', $validator->errors(), 422);
            }
        
        $data = $request->all();
		$data['order_id'] = Carbon::now()->timestamp.rand(100,999);
		$data['url'] = 'https://api.paysprint.in/api/v1/service/dmt/kyc/transact/transact/send_otp';
		$data['payload'] = '{     
			"mobile":"'.$data['number'].'",
			"pincode":110085,     
			"address":"New Delhi",     
			"dob":"01-07-1981",     
			"gst_state":"07",
			"referenceid":"'.$data['order_id'].'",  
			"txntype":"'.$data['type'].'",  
			"bene_id":"'.$data['ben_id'].'",     
			"lat":"'.$data['latitude'].'",     
			"long":"'.$data['longitude'].'",     
			"amount":"'.$data['amount'].'"
		}';
		$data['method'] = 'POST';
        $res = Psprint::service($data);
        
            if ($res) {
                if ($res['response_code'] === 1) {
                    return ResponseHelper::success(
                        $res['message'] ?? 'OTP generated successfully',
                        $res['stateresp'] ?? [],
                        200
                    );
                }
        
                return ResponseHelper::error(
                    $res['message'] ?? 'Transaction OTP generation failed',
                    $res,
                    403
                );
            }
        
            return ResponseHelper::error(
                'Service Provider Down',
                [],
                503
            );
        }
}